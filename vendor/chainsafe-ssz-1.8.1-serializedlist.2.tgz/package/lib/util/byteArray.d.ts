import { ByteVector } from "../interface.ts";
/** Wrapper to select Uint8Array.slice or Uint8Array.subarray */
export declare function slice(data: Uint8Array, start?: number, end?: number, reuseBytes?: boolean): Uint8Array;
export declare function toHexString(bytes: Uint8Array | ByteVector): string;
export declare function fromHexString(hex: string): Uint8Array;
export declare function byteArrayEquals(a: Uint8Array, b: Uint8Array): boolean;
