import { Node } from "@chainsafe/persistent-merkle-tree";
import { ContainerType } from "../type/container.ts";
/** Upgrade the current View/ViewDU to a root node of new type */
export declare function upgradeToNewType(rootNode: Node, oldType: ContainerType<any>, newType: ContainerType<any>): Node;
