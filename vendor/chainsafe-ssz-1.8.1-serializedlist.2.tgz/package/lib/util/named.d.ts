export declare function namedClass<T>(superClass: T, className: string): T;
