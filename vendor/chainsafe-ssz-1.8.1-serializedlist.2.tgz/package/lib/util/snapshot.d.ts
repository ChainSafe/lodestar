import { Snapshot } from "./types.ts";
/**
 * Create a zero snapshot with the given chunksDepth.
 */
export declare function zeroSnapshot(chunkDepth: number): Snapshot;
