/** Dedicated property to cache hashTreeRoot of immutable CompositeType values */
export declare const symbolCachedPermanentRoot: unique symbol;
/** Helper type to cast CompositeType values that may have @see symbolCachedPermanentRoot */
export type ValueWithCachedPermanentRoot = {
    [symbolCachedPermanentRoot]?: Uint8Array;
};
/**
 * Cache a root for a ValueWithCachedPermanentRoot instance
 * - if safeCache is true and output is 32 bytes and offset is 0, use output directly
 * - if safeCache, use output subarray
 * - otherwise, need to clone the root at output offset
 */
export declare function cacheRoot(value: ValueWithCachedPermanentRoot, output: Uint8Array, offset: number, safeCache: boolean): void;
export declare function hash64(bytes32A: Uint8Array, bytes32B: Uint8Array): Uint8Array;
export declare function merkleize(chunks: Uint8Array[], padFor: number): Uint8Array;
/** @ignore */
export declare function mixInLength(root: Uint8Array, length: number): Uint8Array;
export declare function bitLength(i: number): number;
/**
 * Given maxChunkCount return the chunkDepth
 * ```
 * n: [0,1,2,3,4,5,6,7,8,9]
 * d: [0,0,1,2,2,3,3,3,3,4]
 * ```
 */
export declare function maxChunksToDepth(n: number): number;
/** @ignore */
export declare function nextPowerOf2(n: number): number;
