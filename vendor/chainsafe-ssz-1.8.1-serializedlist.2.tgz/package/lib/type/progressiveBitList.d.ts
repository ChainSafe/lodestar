import { Gindex, Node, Proof } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { BitArray } from "../value/bitArray.ts";
import { BitArrayType } from "./bitArray.ts";
import { ByteViews } from "./composite.ts";
export interface ProgressiveBitListOptions {
    typeName?: string;
    /** Optional runtime limit on bit length, 0 requires an empty list. Does not affect the progressive Merkle tree shape. */
    limit?: number;
}
/**
 * ProgressiveBitList: variable-length collection of boolean values without a Merkleization limit.
 * - Serialization is identical to BitList, including the padding bit.
 * - Merkleization uses EIP-7916 progressive merkleization.
 */
export declare class ProgressiveBitListType extends BitArrayType {
    readonly typeName: string;
    readonly depth = 1;
    readonly chunkDepth = 0;
    readonly fixedSize: null;
    readonly minSize = 1;
    readonly maxSize: number;
    readonly maxChunkCount: number;
    readonly isList = true;
    readonly limitBits: number;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    constructor(opts?: ProgressiveBitListOptions);
    static named(opts: Require<ProgressiveBitListOptions, "typeName">): ProgressiveBitListType;
    defaultValue(): BitArray;
    createFromProof(proof: Proof, root?: Uint8Array): ReturnType<BitArrayType["getView"]>;
    value_serializedSize(value: BitArray): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: BitArray): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): BitArray;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getByteLen(node?: Node): number;
    hashTreeRoot(value: BitArray): Uint8Array;
    hashTreeRootInto(value: BitArray, output: Uint8Array, offset: number): void;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    private deserializeUint8ArrayBitListFromBytes;
}
