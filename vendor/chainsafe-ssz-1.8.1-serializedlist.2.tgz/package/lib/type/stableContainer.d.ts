import { Gindex, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { BitArray } from "../value/bitArray.ts";
import { ContainerTreeViewType, ContainerTreeViewTypeConstructor, FieldEntry, ValueOfFields, getContainerTreeViewClass } from "../view/stableContainer.ts";
import { ContainerTreeViewDUType, ContainerTreeViewDUTypeConstructor, getContainerTreeViewDUClass } from "../viewDU/stableContainer.ts";
import { JsonPath, Type } from "./abstract.ts";
import { ByteViews, CompositeType } from "./composite.ts";
import { NonOptionalFields } from "./optional.ts";
type BytesRange = {
    start: number;
    end: number;
};
export type StableContainerOptions<Fields extends Record<string, unknown>> = {
    typeName?: string;
    jsonCase?: KeyCase;
    casingMap?: CasingMap<Fields>;
    cachePermanentRootStruct?: boolean;
    getContainerTreeViewClass?: typeof getContainerTreeViewClass;
    getContainerTreeViewDUClass?: typeof getContainerTreeViewDUClass;
};
export type KeyCase = "eth2" | "snake" | "constant" | "camel" | "header" | "pascal";
type CasingMap<Fields extends Record<string, unknown>> = Partial<{
    [K in keyof Fields]: string;
}>;
/**
 * StableContainer: ordered heterogeneous collection of values
 * - EIP: https://eips.ethereum.org/EIPS/eip-7495
 * - Notation: Custom name per instance
 */
export declare class StableContainerType<Fields extends Record<string, Type<unknown>>> extends CompositeType<ValueOfFields<Fields>, ContainerTreeViewType<Fields>, ContainerTreeViewDUType<Fields>> {
    readonly maxFields: number;
    readonly opts?: StableContainerOptions<Fields> | undefined;
    readonly typeName: string;
    readonly depth: number;
    readonly maxChunkCount: number;
    readonly fixedSize: number | null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = false;
    readonly isViewMutable = true;
    readonly fields: Fields;
    readonly fieldsEntries: FieldEntry<NonOptionalFields<Fields>>[];
    /** End of fixed section of serialized Container */
    protected readonly fieldsGindex: Record<keyof Fields, Gindex>;
    protected readonly jsonKeyToFieldName: Record<string, keyof Fields>;
    /** Cached TreeView constuctor with custom prototype for this Type's properties */
    protected readonly TreeView: ContainerTreeViewTypeConstructor<Fields>;
    protected readonly TreeViewDU: ContainerTreeViewDUTypeConstructor<Fields>;
    private padActiveFields;
    private tempRoot;
    constructor(fields: Fields, maxFields: number, opts?: StableContainerOptions<Fields> | undefined);
    static named<Fields extends Record<string, Type<unknown>>>(fields: Fields, maxFields: number, opts: Require<StableContainerOptions<Fields>, "typeName">): StableContainerType<Fields>;
    defaultValue(): ValueOfFields<Fields>;
    getView(tree: Tree): ContainerTreeViewType<Fields>;
    getViewDU(node: Node, cache?: unknown): ContainerTreeViewDUType<Fields>;
    cacheOfViewDU(view: ContainerTreeViewDUType<Fields>): unknown;
    commitView(view: ContainerTreeViewType<Fields>): Node;
    commitViewDU(view: ContainerTreeViewDUType<Fields>): Node;
    value_serializedSize(value: ValueOfFields<Fields>): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOfFields<Fields>): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ValueOfFields<Fields>;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    hashTreeRootInto(value: ValueOfFields<Fields>, output: Uint8Array, offset: number, safeCache?: boolean): void;
    protected getBlocksBytes(struct: ValueOfFields<Fields>): Uint8Array;
    getPropertyGindex(prop: string): Gindex | null;
    getPropertyType(prop: string): Type<unknown>;
    getIndexProperty(index: number): string | null;
    tree_createProofGindexes(node: Node, jsonPaths: JsonPath[]): Gindex[];
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    fromJson(json: unknown): ValueOfFields<Fields>;
    toJson(value: ValueOfFields<Fields>): Record<string, unknown>;
    clone(value: ValueOfFields<Fields>): ValueOfFields<Fields>;
    equals(a: ValueOfFields<Fields>, b: ValueOfFields<Fields>): boolean;
    /**
     * `activeFields` is a bitvector prepended to the serialized data.
     */
    getFieldRanges(data: ByteViews, start: number, end: number): {
        activeFields: BitArray;
        fieldRanges: BytesRange[];
    };
    tree_getActiveFields(rootNode: Node): BitArray;
    tree_setActiveFields(rootNode: Node, activeFields: BitArray): Node;
    tree_getActiveField(rootNode: Node, fieldIndex: number): boolean;
    tree_setActiveField(rootNode: Node, fieldIndex: number, value: boolean): Node;
}
/**
 * Compute the JSON key for each fieldName. There will exist a single JSON representation for each type.
 * To transform JSON payloads to a casing that is different from the type's defined use external tooling.
 */
export declare function precomputeJsonKey<Fields extends Record<string, Type<unknown>>>(fieldName: keyof Fields, casingMap?: CasingMap<Fields>, jsonCase?: KeyCase): string;
/**
 * Render field typeNames for a detailed typeName of this Container
 */
export declare function renderContainerTypeName<Fields extends Record<string, Type<unknown>>>(fields: Fields, prefix?: string): string;
/**
 * Get the active field bitvector, given the root of the tree and # of fields
 */
export declare function getActiveFields(rootNode: Node, bitLen: number): BitArray;
export declare function setActiveFields(rootNode: Node, activeFields: BitArray): Node;
export declare function getActiveField(rootNode: Node, bitLen: number, fieldIndex: number): boolean;
export declare function setActiveField(rootNode: Node, bitLen: number, fieldIndex: number, value: boolean): Node;
export declare function mixInActiveFields(root: Uint8Array, activeFields: BitArray, output: Uint8Array, offset: number): void;
export {};
