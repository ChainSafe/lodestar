import { Node } from "@chainsafe/persistent-merkle-tree";
import { ByteViews, ValueOf } from "./abstract.ts";
import { CompositeType } from "./composite.ts";
export type ArrayProps = {
    isList: true;
    limit: number;
} | {
    isList: false;
    length: number;
};
export declare function minSizeArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, minCount: number): number;
export declare function maxSizeArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, maxCount: number): number;
export declare function value_serializedSizeArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, length: number, value: ValueOf<ElementType>[]): number;
/**
 * @param length In List length = value.length, Vector length = fixed value
 */
export declare function value_serializeToBytesArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, length: number, output: ByteViews, offset: number, value: ValueOf<ElementType>[]): number;
export declare function value_deserializeFromBytesArrayComposite<ElementType extends CompositeType<ValueOf<ElementType>, unknown, unknown>>(elementType: ElementType, data: ByteViews, start: number, end: number, arrayProps: ArrayProps, reuseBytes?: boolean): ValueOf<ElementType>[];
/**
 * @param length In List length = value.length, Vector length = fixed value
 */
export declare function tree_serializedSizeArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, length: number, depth: number, node: Node): number;
/**
 * @param length In List length = value.length, Vector length = fixed value
 */
export declare function tree_serializeToBytesArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, length: number, depth: number, node: Node, output: ByteViews, offset: number, cachedNodes?: Node[] | null): number;
export declare function tree_deserializeFromBytesArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, chunkDepth: number, data: ByteViews, start: number, end: number, arrayProps: ArrayProps): Node;
export declare function value_getBlocksBytesArrayComposite<ElementType extends CompositeType<unknown, unknown, unknown>>(elementType: ElementType, length: number, value: ValueOf<ElementType>[], blocksBuffer: Uint8Array): Uint8Array;
/**
 * Reads the values of contiguous variable offsets. Provided buffer includes offsets that point to position
 * within `size`. This function also validates that all offsets are in range.
 *
 * @param withEndOffset if true, the returned array has one extra trailing entry equal to `size`
 */
export declare function readVariableOffsetsArrayComposite(dataView: DataView, start: number, size: number, withEndOffset?: boolean): Uint32Array;
