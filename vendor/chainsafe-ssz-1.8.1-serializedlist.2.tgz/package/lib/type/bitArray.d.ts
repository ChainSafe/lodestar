import { Gindex, HashComputationLevel, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { BitArray } from "../value/bitArray.ts";
import { BitArrayTreeView } from "../view/bitArray.ts";
import { BitArrayTreeViewDU } from "../viewDU/bitArray.ts";
import { CompositeType } from "./composite.ts";
/**
 * BitArray: ordered array collection of boolean values
 * - Value: `BitArray`, @see BitArray for a justification of its memory efficiency and performance
 * - View: `BitArrayTreeView`
 * - ViewDU: `BitArrayTreeViewDU`
 */
export declare abstract class BitArrayType extends CompositeType<BitArray, BitArrayTreeView, BitArrayTreeViewDU> {
    readonly isViewMutable = true;
    getView(tree: Tree): BitArrayTreeView;
    getViewDU(node: Node): BitArrayTreeViewDU;
    commitView(view: BitArrayTreeView): Node;
    commitViewDU(view: BitArrayTreeViewDU, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(view: BitArrayTreeViewDU): unknown;
    protected getBlocksBytes(value: BitArray): Uint8Array;
    getPropertyGindex(): null;
    getPropertyType(): never;
    getIndexProperty(): never;
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
    tree_getLeafGindices(rootGindex: bigint, rootNode?: Node): Gindex[];
    abstract tree_getByteLen(node?: Node): number;
    fromJson(json: unknown): BitArray;
    toJson(value: BitArray): unknown;
    clone(value: BitArray): BitArray;
    equals(a: BitArray, b: BitArray): boolean;
}
