import { Gindex, HashComputationLevel, Node, Proof, Tree } from "@chainsafe/persistent-merkle-tree";
import { SerializedList } from "../value/serializedList.ts";
import { ListCompositeTreeView } from "../view/listComposite.ts";
import { ListCompositeTreeViewDU } from "../viewDU/listComposite.ts";
import { ByteViews, JsonPathProp, Type } from "./abstract.ts";
import { ByteListType } from "./byteList.ts";
import { CompositeType } from "./composite.ts";
import { ProgressiveByteListType } from "./progressiveByteList.ts";
import { ProgressiveListCompositeTreeView, ProgressiveListCompositeTreeViewDU } from "./progressiveList.ts";
export interface SerializedListOpts {
    typeName?: string;
    cachePermanentRootStruct?: boolean;
}
export interface ProgressiveSerializedListOpts extends SerializedListOpts {
    /** Optional runtime limit on element count, 0 requires an empty list. Does not affect the progressive Merkle tree shape. */
    limit?: number;
}
/** Element types supported by SerializedList types, both have a `Uint8Array` value */
export type SerializedListElementType = ByteListType | ProgressiveByteListType;
/** The list type with `Uint8Array[]` values that a SerializedList type is equivalent to */
type InnerListType<TV, TVDU> = CompositeType<Uint8Array[], TV, TVDU> & {
    readonly limit: number;
    readonly elementType: SerializedListElementType;
};
/**
 * Same SSZ type as `inner` (a list of ByteList or ProgressiveByteList) but its value is a `SerializedList`: the canonical serialization in a
 * single Uint8Array plus element offsets, instead of one Uint8Array per element. Deserializing a list of many tiny
 * elements then allocates 2 objects instead of one per element.
 *
 * Serialization, merkleization, JSON and proofs are identical to `inner`. Tree-backed views are the views of `inner`,
 * only the value representation changes.
 */
declare abstract class SerializedListBaseType<TV, TVDU> extends CompositeType<SerializedList, TV, TVDU> {
    readonly elementType: SerializedListElementType;
    /** Equivalent list type with `Uint8Array[]` values, used for tree operations and views */
    readonly inner: InnerListType<TV, TVDU>;
    readonly typeName: string;
    readonly depth: number;
    readonly maxChunkCount: number;
    readonly fixedSize: null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = true;
    readonly isViewMutable = true;
    readonly limit: number;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    constructor(elementType: SerializedListElementType, 
    /** Equivalent list type with `Uint8Array[]` values, used for tree operations and views */
    inner: InnerListType<TV, TVDU>, cachePermanentRootStruct?: boolean);
    /** Merkleize the roots of all elements of `value` (without length mix in) into `output[0, 32)` */
    protected abstract merkleizeElements(value: SerializedList, output: Uint8Array): void;
    defaultValue(): SerializedList;
    getView(tree: Tree): TV;
    getViewDU(node: Node, cache?: unknown): TVDU;
    commitView(view: TV): Node;
    commitViewDU(view: TVDU, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(view: TVDU): unknown;
    createFromProof(proof: Proof, root?: Uint8Array): TV;
    value_serializedSize(value: SerializedList): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: SerializedList): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): SerializedList;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    value_toTree(value: SerializedList): Node;
    tree_toValue(node: Node): SerializedList;
    tree_getLength(node: Node): number;
    hashTreeRootInto(value: SerializedList, output: Uint8Array, offset: number, safeCache?: boolean): void;
    /** Write hashTreeRoot of element `index` of `value` into `output[offset, offset + 32)` without allocating it */
    protected hashElementInto(value: SerializedList, index: number, output: Uint8Array, offset: number): void;
    protected getBlocksBytes(): Uint8Array;
    getPropertyGindex(prop: JsonPathProp): Gindex | null;
    getPropertyType(prop: JsonPathProp): Type<unknown>;
    getIndexProperty(index: number): JsonPathProp | null;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
    fromJson(json: unknown): SerializedList;
    toJson(value: SerializedList): unknown;
    clone(value: SerializedList): SerializedList;
    equals(a: SerializedList, b: SerializedList): boolean;
}
/**
 * `List[ByteList[N], LIMIT]` (or of ProgressiveByteList) with a `SerializedList` value, equivalent to
 * `ListCompositeType(elementType, LIMIT)`.
 * @see SerializedListBaseType
 */
export declare class SerializedListType extends SerializedListBaseType<ListCompositeTreeView<SerializedListElementType>, ListCompositeTreeViewDU<SerializedListElementType>> {
    private readonly blockArray;
    constructor(elementType: SerializedListElementType, limit: number, opts?: SerializedListOpts);
    protected merkleizeElements(value: SerializedList, output: Uint8Array): void;
}
/**
 * `ProgressiveList[ProgressiveByteList]` with a `SerializedList` value, equivalent to
 * `ProgressiveListCompositeType(elementType, opts)`.
 * @see SerializedListBaseType
 */
export declare class ProgressiveSerializedListType extends SerializedListBaseType<ProgressiveListCompositeTreeView<SerializedListElementType>, ProgressiveListCompositeTreeViewDU<SerializedListElementType>> {
    constructor(elementType: SerializedListElementType, opts?: ProgressiveSerializedListOpts);
    protected merkleizeElements(value: SerializedList, output: Uint8Array): void;
}
export {};
