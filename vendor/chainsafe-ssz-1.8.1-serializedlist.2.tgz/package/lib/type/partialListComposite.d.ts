import { Snapshot } from "../util/types.ts";
import { PartialListCompositeTreeViewDU } from "../viewDU/partialListComposite.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "./composite.ts";
import { ListCompositeOpts, ListCompositeType } from "./listComposite.ts";
/**
 * Similar to ListCompositeType, this is mainly used to create a PartialListCompositeTreeViewDU from a snapshot.
 * The ViewDU created is a partial tree created from a snapshot, not a full tree.
 * Note that this class only inherits minimal methods as defined in ArrayType of ../view/arrayBasic.ts
 * It'll throw errors for all other methods, most of the usage is in the ViewDU class.
 */
export declare class PartialListCompositeType<ElementType extends CompositeType<any, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends ListCompositeType<ElementType> {
    readonly elementType: ElementType;
    readonly limit: number;
    constructor(elementType: ElementType, limit: number, opts?: ListCompositeOpts);
    /**
     * Create a PartialListCompositeTreeViewDU from a snapshot.
     */
    toPartialViewDU(snapshot: Snapshot): PartialListCompositeTreeViewDU<ElementType>;
    /**
     * Creates a PartialListCompositeTreeViewDU from a zero snapshot.
     */
    defaultPartialViewDU(): PartialListCompositeTreeViewDU<ElementType>;
}
