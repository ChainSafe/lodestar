import { Gindex, HashComputationLevel, Node, Proof, Tree } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { TreeView } from "../view/abstract.ts";
import { TreeViewDU } from "../viewDU/abstract.ts";
import { ByteViews, JsonPath, Type } from "./abstract.ts";
import { CompositeType } from "./composite.ts";
export type CompatibleUnion<T> = {
    readonly selector: number;
    data: T;
};
export type CompatibleUnionOpts = {
    typeName?: string;
};
/**
 * CompatibleUnion: union type containing one of the given subtypes with compatible Merkleization.
 * - Notation: CompatibleUnion({selector: type}), e.g. CompatibleUnion({1: Square, 2: Circle})
 *
 * The right leaf encodes the selector and reuses existing list length-node helpers for tree operations.
 */
export declare class CompatibleUnionType<Types extends Record<number, Type<unknown>>> extends CompositeType<CompatibleUnion<unknown>, CompatibleUnionTreeView<Types>, CompatibleUnionTreeViewDU<Types>> {
    readonly typeName: string;
    readonly depth = 1;
    readonly maxChunkCount = 1;
    readonly fixedSize: null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = true;
    readonly isViewMutable = true;
    readonly mixInSelectorBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInSelectorBuffer: Buffer<ArrayBufferLike>;
    readonly selectors: number[];
    private readonly selectorToType;
    private readonly representativeType;
    private readonly selectorType;
    constructor(options: Types, opts?: CompatibleUnionOpts);
    static named<Types extends Record<number, Type<unknown>>>(options: Types, opts: Require<CompatibleUnionOpts, "typeName">): CompatibleUnionType<Types>;
    defaultValue(): CompatibleUnion<unknown>;
    getView(tree: Tree): CompatibleUnionTreeView<Types>;
    getViewDU(node: Node): CompatibleUnionTreeViewDU<Types>;
    cacheOfViewDU(): unknown;
    commitView(view: CompatibleUnionTreeView<Types>): Node;
    commitViewDU(view: CompatibleUnionTreeViewDU<Types>, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    value_serializedSize(value: CompatibleUnion<unknown>): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: CompatibleUnion<unknown>): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): CompatibleUnion<unknown>;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    hashTreeRoot(value: CompatibleUnion<unknown>): Uint8Array;
    hashTreeRootInto(value: CompatibleUnion<unknown>, output: Uint8Array, offset: number): void;
    protected getBlocksBytes(value: CompatibleUnion<unknown>): Uint8Array;
    getPropertyGindex(prop: string): Gindex;
    createFromProof(proof: Proof, root?: Uint8Array): CompatibleUnionTreeView<Types>;
    tree_createProof(node: Node, jsonPaths: JsonPath[]): Proof;
    tree_createProofGindexes(node: Node, jsonPaths: JsonPath[]): Gindex[];
    getPropertyType(prop: string): Type<unknown>;
    getIndexProperty(index: number): string;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
    fromJson(json: unknown): CompatibleUnion<unknown>;
    toJson(value: CompatibleUnion<unknown>): Record<string, unknown>;
    clone(value: CompatibleUnion<unknown>): CompatibleUnion<unknown>;
    equals(a: CompatibleUnion<unknown>, b: CompatibleUnion<unknown>): boolean;
    getType(selector: number): Type<unknown>;
}
export declare class CompatibleUnionTreeView<Types extends Record<number, Type<unknown>>> extends TreeView<CompatibleUnionType<Types>> {
    readonly type: CompatibleUnionType<Types>;
    protected tree: Tree;
    constructor(type: CompatibleUnionType<Types>, tree: Tree);
    get node(): Node;
    get selector(): number;
    get data(): unknown;
}
export declare class CompatibleUnionTreeViewDU<Types extends Record<number, Type<unknown>>> extends TreeViewDU<CompatibleUnionType<Types>> {
    readonly type: CompatibleUnionType<Types>;
    protected _rootNode: Node;
    constructor(type: CompatibleUnionType<Types>, _rootNode: Node);
    get node(): Node;
    get cache(): unknown;
    get selector(): number;
    get data(): unknown;
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    protected clearCache(): void;
}
export declare function areTypesCompatible(a: Type<unknown>, b: Type<unknown>): boolean;
