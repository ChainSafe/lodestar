import { Node } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { ByteArray, ByteArrayType } from "./byteArray.ts";
import { ByteViews } from "./composite.ts";
export interface ByteListOptions {
    typeName?: string;
}
/**
 * ByteList: Immutable alias of List[byte, N]
 * - Notation: `ByteList[N]`
 * - Value: `Uint8Array`
 * - View: `Uint8Array`
 * - ViewDU: `Uint8Array`
 *
 * ByteList is an immutable value which is represented by a Uint8Array for memory efficiency and performance.
 * Note: Consumers of this type MUST never mutate the `Uint8Array` representation of a ByteList.
 *
 * For a `ByteListType` with mutability, use `ListBasicType(byteType)`
 */
export declare class ByteListType extends ByteArrayType {
    readonly limitBytes: number;
    readonly typeName: string;
    readonly depth: number;
    readonly chunkDepth: number;
    readonly fixedSize: null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly maxChunkCount: number;
    readonly isList = true;
    readonly blockArray: Uint8Array[];
    private blockBytesLen;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    constructor(limitBytes: number, opts?: ByteListOptions);
    static named(limitBits: number, opts: Require<ByteListOptions, "typeName">): ByteListType;
    value_serializedSize(value: Uint8Array): number;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getByteLen(node?: Node): number;
    hashTreeRoot(value: ByteArray): Uint8Array;
    /**
     * Use  merkleizeBlockArray() instead of merkleizeBlocksBytes() to avoid big memory allocation
     */
    hashTreeRootInto(value: Uint8Array, output: Uint8Array, offset: number): void;
    /**
     * Same to hashTreeRootInto() but the value is `data[start, end)`, so callers holding many ByteList values
     * in a single buffer don't need to allocate one Uint8Array per value.
     */
    hashTreeRootFromBytesInto(data: Uint8Array, start: number, end: number, output: Uint8Array, offset: number): void;
    protected assertValidSize(size: number): void;
}
