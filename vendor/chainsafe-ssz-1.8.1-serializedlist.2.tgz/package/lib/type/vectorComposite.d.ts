import { HashComputationLevel, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import type { ArrayLike } from "../interface.ts";
import { Require } from "../util/types.ts";
import { ArrayCompositeTreeView, ArrayCompositeType } from "../view/arrayComposite.ts";
import { ArrayCompositeTreeViewDU } from "../viewDU/arrayComposite.ts";
import { ByteViews, Type, ValueOf } from "./abstract.ts";
import { ArrayType } from "./array.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "./composite.ts";
import type { ListBasicType } from "./listBasic.ts";
import type { VectorBasicType } from "./vectorBasic.ts";
/**
 * Input element type accepted by the outer composite.
 * When the element is a basic vector/list, allow any `ArrayLike` of the basic value
 * (e.g. `Uint32Array` for a `VectorBasicType<UintNumberType>`), not only plain `number[]`.
 */
type CompositeElementInput<ElementType extends Type<unknown>> = ElementType extends VectorBasicType<infer B> ? ArrayLike<ValueOf<B>> : ElementType extends ListBasicType<infer B> ? ArrayLike<ValueOf<B>> : ValueOf<ElementType>;
export type VectorCompositeOpts = {
    typeName?: string;
};
/**
 * Vector: Ordered fixed-length homogeneous collection, with N values
 *
 * Array of Composite type:
 * - Composite types always take at least one chunk
 * - Composite types are always returned as views
 */
export declare class VectorCompositeType<ElementType extends CompositeType<any, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends ArrayType<ElementType, ArrayCompositeTreeView<ElementType>, ArrayCompositeTreeViewDU<ElementType>> implements ArrayCompositeType<ElementType> {
    readonly elementType: ElementType;
    readonly length: number;
    readonly typeName: string;
    readonly itemsPerChunk = 1;
    readonly depth: number;
    readonly chunkDepth: number;
    readonly maxChunkCount: number;
    readonly fixedSize: number | null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = false;
    readonly isViewMutable = true;
    protected readonly defaultLen: number;
    constructor(elementType: ElementType, length: number, opts?: VectorCompositeOpts);
    static named<ElementType extends CompositeType<unknown, CompositeView<ElementType>, CompositeViewDU<ElementType>>>(elementType: ElementType, limit: number, opts: Require<VectorCompositeOpts, "typeName">): VectorCompositeType<ElementType>;
    getView(tree: Tree): ArrayCompositeTreeView<ElementType>;
    toView(value: ValueOf<ElementType>[]): ArrayCompositeTreeView<ElementType>;
    toView(value: ArrayLike<CompositeElementInput<ElementType>>): ArrayCompositeTreeView<ElementType>;
    getViewDU(node: Node, cache?: unknown): ArrayCompositeTreeViewDU<ElementType>;
    toViewDU(value: ValueOf<ElementType>[]): ArrayCompositeTreeViewDU<ElementType>;
    toViewDU(value: ArrayLike<CompositeElementInput<ElementType>>): ArrayCompositeTreeViewDU<ElementType>;
    commitView(view: ArrayCompositeTreeView<ElementType>): Node;
    commitViewDU(view: ArrayCompositeTreeViewDU<ElementType>, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(view: ArrayCompositeTreeViewDU<ElementType>): unknown;
    value_serializedSize(value: ValueOf<ElementType>[]): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOf<ElementType>[]): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ValueOf<ElementType>[];
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getLength(): number;
    tree_setLength(): void;
    tree_getChunksNode(node: Node): Node;
    tree_chunksNodeOffset(): number;
    tree_setChunksNode(_rootNode: Node, chunksNode: Node): Node;
    protected getBlocksBytes(value: ValueOf<ElementType>[]): Uint8Array;
}
export {};
