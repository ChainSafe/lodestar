import { Gindex, Node } from "@chainsafe/persistent-merkle-tree";
export declare const PROGRESSIVE_LIST_MAX_SIZE = 4294967295;
/**
 * Return the generalized index of a chunk inside a progressive Merkle tree.
 *
 * The progressive tree is a right-recursive, zero-terminated sequence of
 * subtrees with capacities 1, 4, 16, ...
 */
export declare function progressiveChunkGindex(chunkIndex: number): Gindex;
export declare function progressiveChunkGindexFromRoot(rootGindex: Gindex, chunkIndex: number): Gindex;
export declare function progressiveSubtreeCount(chunkCount: number): number;
export declare function progressiveSubtreeDepth(subtreeIndex: number): number;
export declare function merkleizeProgressiveBytes(chunksBytes: Uint8Array, chunkCount: number, output: Uint8Array, offset: number): void;
export declare function progressiveSubtreeFillToContents(nodes: Node[]): Node;
export declare function getNodesAtProgressiveDepth(rootNode: Node, count: number): Node[];
