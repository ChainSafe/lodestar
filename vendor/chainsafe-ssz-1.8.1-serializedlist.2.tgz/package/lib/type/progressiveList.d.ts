import { Gindex, HashComputationLevel, LeafNode, Node, Proof, Tree } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { TreeView } from "../view/abstract.ts";
import { TreeViewDU } from "../viewDU/abstract.ts";
import { ValueOf } from "./abstract.ts";
import { ArrayType } from "./array.ts";
import { BasicType } from "./basic.ts";
import { ByteViews } from "./composite.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "./composite.ts";
export interface ProgressiveListOpts {
    typeName?: string;
    cachePermanentRootStruct?: boolean;
    /** Optional runtime limit on element count, 0 requires an empty list. Does not affect the progressive Merkle tree shape. */
    limit?: number;
}
export declare class ProgressiveListBasicType<ElementType extends BasicType<unknown>> extends ArrayType<ElementType, ProgressiveListBasicTreeView<ElementType>, ProgressiveListBasicTreeViewDU<ElementType>> {
    readonly elementType: ElementType;
    readonly typeName: string;
    readonly itemsPerChunk: number;
    readonly depth = 1;
    readonly chunkDepth = 0;
    readonly maxChunkCount: number;
    readonly fixedSize: null;
    readonly minSize = 0;
    readonly maxSize: number;
    readonly isList = true;
    readonly isViewMutable = true;
    readonly limit: number;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    protected readonly defaultLen = 0;
    constructor(elementType: ElementType, opts?: ProgressiveListOpts);
    static named<ElementType extends BasicType<unknown>>(elementType: ElementType, opts: Require<ProgressiveListOpts, "typeName">): ProgressiveListBasicType<ElementType>;
    getView(tree: Tree): ProgressiveListBasicTreeView<ElementType>;
    getViewDU(node: Node, cache?: unknown): ProgressiveListBasicTreeViewDU<ElementType>;
    commitView(view: ProgressiveListBasicTreeView<ElementType>): Node;
    commitViewDU(view: ProgressiveListBasicTreeViewDU<ElementType>, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(view: ProgressiveListBasicTreeViewDU<ElementType>): unknown;
    createFromProof(proof: Proof, root?: Uint8Array): ProgressiveListBasicTreeView<ElementType>;
    value_serializedSize(value: ValueOf<ElementType>[]): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOf<ElementType>[]): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number): ValueOf<ElementType>[];
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getLength(node: Node): number;
    tree_setLength(tree: Tree, length: number): void;
    tree_getChunksNode(node: Node): Node;
    tree_chunksNodeOffset(): number;
    tree_setChunksNode(rootNode: Node, chunksNode: Node, newLength: number | null, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    hashTreeRoot(value: ValueOf<ElementType>[]): Uint8Array;
    hashTreeRootInto(value: ValueOf<ElementType>[], output: Uint8Array, offset: number, safeCache?: boolean): void;
    protected getBlocksBytes(value: ValueOf<ElementType>[]): Uint8Array;
    getPropertyGindex(prop: string | number): Gindex;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
}
export declare class ProgressiveListCompositeType<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends ArrayType<ElementType, ProgressiveListCompositeTreeView<ElementType>, ProgressiveListCompositeTreeViewDU<ElementType>> {
    readonly elementType: ElementType;
    readonly typeName: string;
    readonly itemsPerChunk = 1;
    readonly depth = 1;
    readonly chunkDepth = 0;
    readonly maxChunkCount: number;
    readonly fixedSize: null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = true;
    readonly isViewMutable = true;
    readonly limit: number;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    protected readonly defaultLen = 0;
    constructor(elementType: ElementType, opts?: ProgressiveListOpts);
    static named<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>>(elementType: ElementType, opts: Require<ProgressiveListOpts, "typeName">): ProgressiveListCompositeType<ElementType>;
    getView(tree: Tree): ProgressiveListCompositeTreeView<ElementType>;
    getViewDU(node: Node, cache?: unknown): ProgressiveListCompositeTreeViewDU<ElementType>;
    commitView(view: ProgressiveListCompositeTreeView<ElementType>): Node;
    commitViewDU(view: ProgressiveListCompositeTreeViewDU<ElementType>, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(view: ProgressiveListCompositeTreeViewDU<ElementType>): unknown;
    createFromProof(proof: Proof, root?: Uint8Array): ProgressiveListCompositeTreeView<ElementType>;
    value_serializedSize(value: ValueOf<ElementType>[]): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOf<ElementType>[]): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ValueOf<ElementType>[];
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getLength(node: Node): number;
    tree_setLength(tree: Tree, length: number): void;
    tree_getChunksNode(node: Node): Node;
    tree_chunksNodeOffset(): number;
    tree_setChunksNode(rootNode: Node, chunksNode: Node, newLength: number | null, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    hashTreeRoot(value: ValueOf<ElementType>[]): Uint8Array;
    hashTreeRootInto(value: ValueOf<ElementType>[], output: Uint8Array, offset: number, safeCache?: boolean): void;
    protected getBlocksBytes(value: ValueOf<ElementType>[]): Uint8Array;
    getPropertyGindex(prop: string | number): Gindex;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
}
export declare class ProgressiveListBasicTreeView<ElementType extends BasicType<unknown>> extends TreeView<ProgressiveListBasicType<ElementType>> {
    readonly type: ProgressiveListBasicType<ElementType>;
    protected tree: Tree;
    constructor(type: ProgressiveListBasicType<ElementType>, tree: Tree);
    get length(): number;
    get node(): Node;
    get(index: number): ValueOf<ElementType>;
    set(index: number, value: ValueOf<ElementType>): void;
    getAll(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
}
export type ProgressiveListBasicTreeViewDUCache = {
    nodes: LeafNode[];
    nodesPopulated: boolean;
};
export declare class ProgressiveListBasicTreeViewDU<ElementType extends BasicType<unknown>> extends TreeViewDU<ProgressiveListBasicType<ElementType>> {
    readonly type: ProgressiveListBasicType<ElementType>;
    protected _rootNode: Node;
    /**
     * Sparse cache of chunk leaf nodes by chunk index, always consistent with `_rootNode`.
     * Avoids recomputing the progressive gindex and walking the tree on every `get()`.
     */
    protected nodes: LeafNode[];
    /** True when `nodes` holds every chunk of the list, set by `getAll()` */
    private nodesPopulated;
    constructor(type: ProgressiveListBasicType<ElementType>, _rootNode: Node, cache?: ProgressiveListBasicTreeViewDUCache);
    get length(): number;
    get node(): Node;
    get cache(): ProgressiveListBasicTreeViewDUCache;
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    get(index: number): ValueOf<ElementType>;
    set(index: number, value: ValueOf<ElementType>): void;
    push(value: ValueOf<ElementType>): void;
    /**
     * Get all values of this list. Populates the chunk node cache, so subsequent `get()` calls do not walk the tree.
     */
    getAll(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
    /**
     * Returns a new ProgressiveListBasicTreeViewDU instance with the values from 0 to `index`.
     * To achieve it, rebinds the underlying tree zero-ing all nodes right of `chunkIndex`.
     * Also set all value right of `index` in the same chunk to 0.
     */
    sliceTo(index: number): this;
    /**
     * Returns a new ProgressiveListBasicTreeViewDU instance with the values from `index` to the end of list.
     */
    sliceFrom(index: number): this;
    protected clearCache(): void;
}
export declare class ProgressiveListCompositeTreeView<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends TreeView<ProgressiveListCompositeType<ElementType>> {
    readonly type: ProgressiveListCompositeType<ElementType>;
    protected tree: Tree;
    constructor(type: ProgressiveListCompositeType<ElementType>, tree: Tree);
    get length(): number;
    get node(): Node;
    get(index: number): CompositeView<ElementType>;
    set(index: number, view: CompositeView<ElementType>): void;
    getAllReadonlyValues(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
}
export declare class ProgressiveListCompositeTreeViewDU<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends TreeViewDU<ProgressiveListCompositeType<ElementType>> {
    readonly type: ProgressiveListCompositeType<ElementType>;
    protected _rootNode: Node;
    private nodes;
    private caches;
    private readonly viewsChanged;
    private nodesPopulated;
    constructor(type: ProgressiveListCompositeType<ElementType>, _rootNode: Node, cache?: ProgressiveListCompositeTreeViewDUCache);
    get length(): number;
    get node(): Node;
    get cache(): ProgressiveListCompositeTreeViewDUCache;
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    get(index: number): CompositeViewDU<ElementType>;
    /**
     * Get element at `index`. Returns a view of the Composite element type.
     * DOES NOT PROPAGATE CHANGES: use only for reads and to skip parent references.
     */
    getReadonly(index: number): CompositeViewDU<ElementType>;
    set(index: number, view: CompositeViewDU<ElementType>): void;
    push(view: CompositeViewDU<ElementType>): void;
    /**
     * Returns all elements at every index, if an index is modified it will return the modified view.
     * No need to commit() before calling this function.
     */
    getAllReadonly(views?: CompositeViewDU<ElementType>[]): CompositeViewDU<ElementType>[];
    /**
     * Apply `fn` to each ViewDU in the array.
     * Similar to getAllReadOnly(), no need to commit() before calling this function.
     * if an item is modified it will return the modified view.
     */
    forEach(fn: (viewDU: CompositeViewDU<ElementType>, index: number) => void): void;
    /**
     * WARNING: Returns all commited changes, if there are any pending changes commit them beforehand
     * @param values optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAllReadonlyValues(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
    /**
     * Apply `fn` to each value in the array.
     */
    forEachValue(fn: (value: ValueOf<ElementType>, index: number) => void): void;
    /**
     * Get by range of indexes. Returns an array of views of the Composite element type.
     * This is similar to getAllReadonly() where we dont have to commit() before calling this function.
     */
    getReadonlyByRange(startIndex: number, count: number): CompositeViewDU<ElementType>[];
    /**
     * Returns a new ProgressiveListCompositeTreeViewDU instance with the values from 0 to `index`.
     * `index` is inclusive.
     */
    sliceTo(index: number): this;
    /**
     * Returns a new ProgressiveListCompositeTreeViewDU instance with the values from `index` to the end of list.
     */
    sliceFrom(index: number): this;
    protected clearCache(): void;
    protected populateAllNodes(): void;
    protected populateAllOldNodes(): void;
    protected rootNodeToViewDU(rootNode: Node): this;
}
type ProgressiveListCompositeTreeViewDUCache = {
    nodes?: Node[];
    caches: unknown[];
    nodesPopulated?: boolean;
};
export {};
