import { LeafNode, Node } from "@chainsafe/persistent-merkle-tree";
import { ByteViews } from "./abstract.ts";
import { BasicType } from "./basic.ts";
export declare class NoneType extends BasicType<null> {
    readonly typeName = "none";
    readonly byteLength = 0;
    readonly itemsPerChunk = 32;
    readonly fixedSize = 0;
    readonly minSize = 0;
    readonly maxSize = 0;
    defaultValue(): null;
    value_serializeToBytes(_output: ByteViews, offset: number, _value: null): number;
    value_deserializeFromBytes(_data: ByteViews, _start: number): null;
    tree_serializeToBytes(_output: ByteViews, offset: number, _node: Node): number;
    tree_deserializeFromBytes(_data: ByteViews, _start: number, _end: number): Node;
    tree_getFromNode(_leafNode: LeafNode): null;
    tree_setToNode(_leafNode: LeafNode, _value: null): void;
    tree_getFromPackedNode(_leafNode: LeafNode, _index: number): null;
    tree_setToPackedNode(_leafNode: LeafNode, _index: number, _value: null): void;
    fromJson(json: unknown): null;
    toJson(_value: null): unknown;
}
