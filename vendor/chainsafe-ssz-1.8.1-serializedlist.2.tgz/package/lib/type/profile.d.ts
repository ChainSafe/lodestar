import { Gindex, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { BitArray } from "../value/bitArray.ts";
import { ContainerTreeViewType, ContainerTreeViewTypeConstructor, FieldEntry, ValueOfFields, getProfileTreeViewClass } from "../view/profile.ts";
import { ContainerTreeViewDUType, ContainerTreeViewDUTypeConstructor, getProfileTreeViewDUClass } from "../viewDU/profile.ts";
import { Type } from "./abstract.ts";
import { ByteViews, CompositeType } from "./composite.ts";
import { NonOptionalFields } from "./optional.ts";
type BytesRange = {
    start: number;
    end: number;
};
export type ProfileOptions<Fields extends Record<string, unknown>> = {
    typeName?: string;
    jsonCase?: KeyCase;
    casingMap?: CasingMap<Fields>;
    cachePermanentRootStruct?: boolean;
    getProfileTreeViewClass?: typeof getProfileTreeViewClass;
    getProfileTreeViewDUClass?: typeof getProfileTreeViewDUClass;
};
export type KeyCase = "eth2" | "snake" | "constant" | "camel" | "header" | "pascal";
type CasingMap<Fields extends Record<string, unknown>> = Partial<{
    [K in keyof Fields]: string;
}>;
/**
 * Profile: ordered heterogeneous collection of values that inherits merkleization from a base stable container
 * - EIP: https://eips.ethereum.org/EIPS/eip-7495
 * - No reordering of fields for merkleization
 */
export declare class ProfileType<Fields extends Record<string, Type<unknown>>> extends CompositeType<ValueOfFields<Fields>, ContainerTreeViewType<Fields>, ContainerTreeViewDUType<Fields>> {
    readonly fields: Fields;
    readonly opts?: ProfileOptions<Fields> | undefined;
    readonly typeName: string;
    readonly depth: number;
    readonly maxChunkCount: number;
    readonly fixedSize: number | null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = false;
    readonly isViewMutable = true;
    readonly activeFields: BitArray;
    readonly fieldsEntries: FieldEntry<NonOptionalFields<Fields>>[];
    /** End of fixed section of serialized Container */
    protected readonly fieldsGindex: Record<keyof Fields, Gindex>;
    protected readonly jsonKeyToFieldName: Record<string, keyof Fields>;
    /** Cached TreeView constuctor with custom prototype for this Type's properties */
    protected readonly TreeView: ContainerTreeViewTypeConstructor<Fields>;
    protected readonly TreeViewDU: ContainerTreeViewDUTypeConstructor<Fields>;
    private optionalFieldsCount;
    private tempRoot;
    constructor(fields: Fields, activeFields: BitArray, opts?: ProfileOptions<Fields> | undefined);
    static named<Fields extends Record<string, Type<unknown>>>(fields: Fields, activeFields: BitArray, opts: Require<ProfileOptions<Fields>, "typeName">): ProfileType<Fields>;
    defaultValue(): ValueOfFields<Fields>;
    getView(tree: Tree): ContainerTreeViewType<Fields>;
    getViewDU(node: Node, cache?: unknown): ContainerTreeViewDUType<Fields>;
    cacheOfViewDU(view: ContainerTreeViewDUType<Fields>): unknown;
    commitView(view: ContainerTreeViewType<Fields>): Node;
    commitViewDU(view: ContainerTreeViewDUType<Fields>): Node;
    value_serializedSize(value: ValueOfFields<Fields>): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOfFields<Fields>): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ValueOfFields<Fields>;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    hashTreeRootInto(value: ValueOfFields<Fields>, output: Uint8Array, offset: number, safeCache?: boolean): void;
    protected getBlocksBytes(struct: ValueOfFields<Fields>): Uint8Array;
    /** INTERNAL METHOD: For view's API, create proof from a tree */
    getPropertyGindex(prop: string): Gindex | null;
    getPropertyType(prop: string): Type<unknown>;
    getIndexProperty(index: number): string | null;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    fromJson(json: unknown): ValueOfFields<Fields>;
    toJson(value: ValueOfFields<Fields>): Record<string, unknown>;
    clone(value: ValueOfFields<Fields>): ValueOfFields<Fields>;
    equals(a: ValueOfFields<Fields>, b: ValueOfFields<Fields>): boolean;
    /**
     * Deserializer helper: Returns the bytes ranges of all fields, both variable and fixed size.
     * Fields may not be contiguous in the serialized bytes, so the returned ranges are [start, end].
     * - For fixed size fields re-uses the pre-computed values this.fieldRangesFixedLen
     * - For variable size fields does a first pass over the fixed section to read offsets
     * - offsets are relative to the start of serialized active fields, after the Bitvector[N]
     */
    getFieldRanges(data: ByteViews, start: number, end: number): {
        optionalFields: BitArray;
        fieldRanges: BytesRange[];
    };
}
/**
 * Compute the JSON key for each fieldName. There will exist a single JSON representation for each type.
 * To transform JSON payloads to a casing that is different from the type's defined use external tooling.
 */
export declare function precomputeJsonKey<Fields extends Record<string, Type<unknown>>>(fieldName: keyof Fields, casingMap?: CasingMap<Fields>, jsonCase?: KeyCase): string;
/**
 * Render field typeNames for a detailed typeName of this Container
 */
export declare function renderContainerTypeName<Fields extends Record<string, Type<unknown>>>(fields: Fields, prefix?: string): string;
export {};
