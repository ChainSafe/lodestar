import { Gindex, HashComputationLevel, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { ByteViews } from "./abstract.ts";
import { CompositeType } from "./composite.ts";
export type ByteArray = Uint8Array;
/**
 * ByteArray: ordered array collection of byte values
 * - Value: `Uint8Array`
 * - View: `Uint8Array`
 * - ViewDU: `Uint8Array`
 *
 * ByteArray is an immutable value which is represented by a Uint8Array for memory efficiency and performance.
 * Note: Consumers of this type MUST never mutate the `Uint8Array` representation of a ByteArray.
 */
export declare abstract class ByteArrayType extends CompositeType<ByteArray, ByteArray, ByteArray> {
    readonly isViewMutable = false;
    defaultValue(): ByteArray;
    getView(tree: Tree): ByteArray;
    getViewDU(node: Node): ByteArray;
    commitView(view: ByteArray): Node;
    commitViewDU(view: ByteArray, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    cacheOfViewDU(): unknown;
    toView(value: ByteArray): ByteArray;
    toViewDU(value: ByteArray): ByteArray;
    value_serializeToBytes(output: ByteViews, offset: number, value: ByteArray): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ByteArray;
    value_toTree(value: ByteArray): Node;
    protected getBlocksBytes(value: ByteArray): Uint8Array;
    getPropertyGindex(): null;
    getPropertyType(): never;
    getIndexProperty(): never;
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
    tree_getLeafGindices(rootGindex: bigint, rootNode?: Node): Gindex[];
    abstract tree_getByteLen(node?: Node): number;
    fromJson(json: unknown): ByteArray;
    toJson(value: ByteArray): unknown;
    clone(value: ByteArray): ByteArray;
    equals(a: Uint8Array, b: Uint8Array): boolean;
    /** Throws the same error as value_deserializeFromBytes() for a value of `size` bytes, without allocating it */
    assertValidByteLength(size: number): void;
    protected abstract assertValidSize(size: number): void;
}
export declare function getBlocksBytes(value: Uint8Array, blocksBuffer: Uint8Array): Uint8Array;
