import { Gindex, HashComputationLevel, Node, Proof, Tree } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { BitArray } from "../value/bitArray.ts";
import { TreeView } from "../view/abstract.ts";
import { TreeViewDU } from "../viewDU/abstract.ts";
import { Type, ValueOf } from "./abstract.ts";
import { BasicType } from "./basic.ts";
import { ByteViews, CompositeType } from "./composite.ts";
type BytesRange = {
    start: number;
    end: number;
};
export type ProgressiveContainerOptions<Fields extends Record<string, unknown>> = {
    typeName?: string;
    jsonCase?: KeyCase;
    casingMap?: CasingMap<Fields>;
    cachePermanentRootStruct?: boolean;
};
export type KeyCase = "eth2" | "snake" | "constant" | "camel" | "header" | "pascal";
type CasingMap<Fields extends Record<string, unknown>> = Partial<{
    [K in keyof Fields]: string;
}>;
export type ValueOfFields<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: ValueOf<Fields[K]>;
};
type FieldsView<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends CompositeType<unknown, infer TV, unknown> ? TV : Fields[K] extends BasicType<infer V> ? V : never;
};
type FieldsViewDU<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends CompositeType<unknown, unknown, infer TVDU> ? TVDU : Fields[K] extends BasicType<infer V> ? V : never;
};
export type ProgressiveContainerTreeViewType<Fields extends Record<string, Type<unknown>>> = FieldsView<Fields> & TreeView<ProgressiveContainerType<Fields>>;
export type ProgressiveContainerTreeViewDUType<Fields extends Record<string, Type<unknown>>> = FieldsViewDU<Fields> & TreeViewDU<ProgressiveContainerType<Fields>>;
type ProgressiveContainerTreeViewTypeConstructor<Fields extends Record<string, Type<unknown>>> = new (type: ProgressiveContainerType<Fields>, tree: Tree) => ProgressiveContainerTreeViewType<Fields>;
type ProgressiveContainerTreeViewDUTypeConstructor<Fields extends Record<string, Type<unknown>>> = new (type: ProgressiveContainerType<Fields>, node: Node, cache?: unknown) => ProgressiveContainerTreeViewDUType<Fields>;
type FieldEntry<Fields extends Record<string, Type<unknown>>> = {
    fieldName: keyof Fields;
    fieldType: Fields[keyof Fields];
    jsonKey: string;
    gindex: Gindex;
    chunkIndex: number;
};
/**
 * ProgressiveContainer: ordered heterogeneous collection with EIP-7916 progressive merkleization.
 * - Serialization is identical to Container over the active fields.
 * - Hash tree root mixes in the active-fields bitvector from the type definition.
 */
export declare class ProgressiveContainerType<Fields extends Record<string, Type<unknown>>> extends CompositeType<ValueOfFields<Fields>, ProgressiveContainerTreeViewType<Fields>, ProgressiveContainerTreeViewDUType<Fields>> {
    readonly fields: Fields;
    readonly opts?: ProgressiveContainerOptions<Fields> | undefined;
    readonly typeName: string;
    readonly depth = 2;
    readonly maxChunkCount: number;
    readonly fixedSize: number | null;
    readonly minSize: number;
    readonly maxSize: number;
    readonly isList = false;
    readonly isViewMutable = true;
    readonly fieldsEntries: FieldEntry<Fields>[];
    readonly activeFields: BitArray;
    protected readonly fieldsGindex: Record<keyof Fields, Gindex>;
    protected readonly jsonKeyToFieldName: Record<string, keyof Fields>;
    protected readonly isFixedLen: boolean[];
    protected readonly fieldRangesFixedLen: BytesRange[];
    protected readonly variableOffsetsPosition: number[];
    readonly fixedEnd: number;
    protected readonly TreeView: ProgressiveContainerTreeViewTypeConstructor<Fields>;
    protected readonly TreeViewDU: ProgressiveContainerTreeViewDUTypeConstructor<Fields>;
    private readonly tempRoot;
    constructor(fields: Fields, activeFields: BitArray | boolean[], opts?: ProgressiveContainerOptions<Fields> | undefined);
    static named<Fields extends Record<string, Type<unknown>>>(fields: Fields, activeFields: BitArray | boolean[], opts: Require<ProgressiveContainerOptions<Fields>, "typeName">): ProgressiveContainerType<Fields>;
    defaultValue(): ValueOfFields<Fields>;
    getView(tree: Tree): ProgressiveContainerTreeViewType<Fields>;
    getViewDU(node: Node, cache?: unknown): ProgressiveContainerTreeViewDUType<Fields>;
    cacheOfViewDU(view: ProgressiveContainerTreeViewDUType<Fields>): unknown;
    commitView(view: ProgressiveContainerTreeViewType<Fields>): Node;
    commitViewDU(view: ProgressiveContainerTreeViewDUType<Fields>, hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): Node;
    createFromProof(proof: Proof, root?: Uint8Array): ProgressiveContainerTreeViewType<Fields>;
    value_serializedSize(value: ValueOfFields<Fields>): number;
    value_serializeToBytes(output: ByteViews, offset: number, value: ValueOfFields<Fields>): number;
    value_deserializeFromBytes(data: ByteViews, start: number, end: number, reuseBytes?: boolean): ValueOfFields<Fields>;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    hashTreeRootInto(value: ValueOfFields<Fields>, output: Uint8Array, offset: number, safeCache?: boolean): void;
    protected getBlocksBytes(struct: ValueOfFields<Fields>): Uint8Array;
    getPropertyGindex(prop: string): Gindex | null;
    getPropertyType(prop: string): Type<unknown>;
    getIndexProperty(index: number): string | null;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    tree_fromProofNode(node: Node): {
        node: Node;
        done: boolean;
    };
    fromJson(json: unknown): ValueOfFields<Fields>;
    toJson(value: ValueOfFields<Fields>): Record<string, unknown>;
    clone(value: ValueOfFields<Fields>): ValueOfFields<Fields>;
    equals(a: ValueOfFields<Fields>, b: ValueOfFields<Fields>): boolean;
    getFieldRanges(data: DataView, start: number, end: number): BytesRange[];
}
export {};
