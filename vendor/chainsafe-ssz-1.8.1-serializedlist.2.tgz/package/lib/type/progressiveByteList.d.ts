import { Gindex, Node, Proof } from "@chainsafe/persistent-merkle-tree";
import { Require } from "../util/types.ts";
import { ByteArray, ByteArrayType } from "./byteArray.ts";
import { ByteViews } from "./composite.ts";
export interface ProgressiveByteListOptions {
    typeName?: string;
    /** Optional runtime limit on byte length, 0 requires an empty list. Does not affect the progressive Merkle tree shape. */
    limit?: number;
}
/**
 * ProgressiveByteList: Immutable alias of ProgressiveList[byte]
 * - Value: `Uint8Array`
 * - View: `Uint8Array`
 * - ViewDU: `Uint8Array`
 *
 * ProgressiveByteList is an immutable value represented by a Uint8Array for memory efficiency and performance.
 * Note: Consumers of this type MUST never mutate the `Uint8Array` representation of a ProgressiveByteList.
 */
export declare class ProgressiveByteListType extends ByteArrayType {
    readonly typeName: string;
    readonly depth = 1;
    readonly chunkDepth = 0;
    readonly fixedSize: null;
    readonly minSize = 0;
    readonly maxSize: number;
    readonly maxChunkCount: number;
    readonly isList = true;
    readonly limitBytes: number;
    readonly mixInLengthBlockBytes: Uint8Array<ArrayBuffer>;
    readonly mixInLengthBuffer: Buffer<ArrayBufferLike>;
    constructor(opts?: ProgressiveByteListOptions);
    static named(opts: Require<ProgressiveByteListOptions, "typeName">): ProgressiveByteListType;
    createFromProof(proof: Proof, root?: Uint8Array): ByteArray;
    value_serializedSize(value: Uint8Array): number;
    tree_serializedSize(node: Node): number;
    tree_serializeToBytes(output: ByteViews, offset: number, node: Node): number;
    tree_deserializeFromBytes(data: ByteViews, start: number, end: number): Node;
    tree_getByteLen(node?: Node): number;
    hashTreeRoot(value: ByteArray): Uint8Array;
    hashTreeRootInto(value: Uint8Array, output: Uint8Array, offset: number): void;
    /**
     * Same to hashTreeRootInto() but the value is `data[start, end)`, so callers holding many ProgressiveByteList values
     * in a single buffer don't need to allocate one Uint8Array per value.
     */
    hashTreeRootFromBytesInto(data: Uint8Array, start: number, end: number, output: Uint8Array, offset: number): void;
    fromJson(json: unknown): ByteArray;
    tree_getLeafGindices(rootGindex: Gindex, rootNode?: Node): Gindex[];
    protected assertValidSize(size: number): void;
}
