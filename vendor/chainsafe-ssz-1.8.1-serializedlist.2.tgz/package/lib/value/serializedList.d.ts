/**
 * Immutable list of byte strings stored as its canonical SSZ serialization, i.e. a `List[ByteList[N], LIMIT]` or a
 * `ProgressiveList[ProgressiveByteList]`
 * kept as a single `Uint8Array` instead of one `Uint8Array` per element.
 *
 * ```
 * bytes:   [offset 0] [offset 1] ... [offset n-1] [element 0] [element 1] ... [element n-1]
 * offsets: [offset 0, offset 1, ..., offset n-1, bytes.length]
 * ```
 *
 * Elements are returned as subarrays of `bytes` without copying. Consumers MUST NOT mutate `bytes` or any returned
 * element, same contract as `ByteListType` / `ProgressiveByteListType` values.
 *
 * Note: `structuredClone()` and `postMessage()` drop the class prototype, send `bytes` instead and deserialize again.
 */
export declare class SerializedList {
    /** Canonical SSZ serialization of the list */
    readonly bytes: Uint8Array;
    /**
     * Start of each element relative to `bytes`, plus a last entry equal to `bytes.length`, so length is n + 1.
     * The extra entry lets element `i` always be `[offsets[i], offsets[i + 1])`, including the last one. List types
     * keep only n offsets and special case the last element instead, see `endEl` in
     * value_deserializeFromBytesArrayComposite(). We need it on every get(), getSize() and hash, not only once.
     */
    readonly offsets: Uint32Array;
    /**
     * INTERNAL: `bytes` must be a canonical SSZ serialization and `offsets` its validated element offsets plus a trailing
     * `bytes.length` entry. Use `SerializedList.fromArray()` or deserialize with an SSZ type instead.
     */
    constructor(
    /** Canonical SSZ serialization of the list */
    bytes: Uint8Array, 
    /**
     * Start of each element relative to `bytes`, plus a last entry equal to `bytes.length`, so length is n + 1.
     * The extra entry lets element `i` always be `[offsets[i], offsets[i + 1])`, including the last one. List types
     * keep only n offsets and special case the last element instead, see `endEl` in
     * value_deserializeFromBytesArrayComposite(). We need it on every get(), getSize() and hash, not only once.
     */
    offsets: Uint32Array);
    static empty(): SerializedList;
    /** Builds the canonical serialization of `items` with one allocation for `bytes` and one for `offsets` */
    static fromArray(items: Uint8Array[]): SerializedList;
    /** Number of elements */
    get length(): number;
    /** Returns element at `index` as a subarray of `bytes`, no copy */
    get(index: number): Uint8Array;
    /** Returns the byte length of element at `index` without allocating */
    getSize(index: number): number;
    [Symbol.iterator](): IterableIterator<Uint8Array>;
    /** Returns all elements as subarrays of `bytes`, allocates one Uint8Array per element */
    toArray(): Uint8Array[];
    private assertValidIndex;
}
