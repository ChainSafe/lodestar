import { Gindex, Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { Type, ValueOf } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { CompositeType } from "../type/composite.ts";
import { NonOptionalFields, OptionalType } from "../type/optional.ts";
import { BitArray } from "../value/bitArray.ts";
import { TreeView } from "./abstract.ts";
export type FieldEntry<Fields extends Record<string, Type<unknown>>> = {
    fieldName: keyof Fields;
    fieldType: Fields[keyof Fields];
    jsonKey: string;
    gindex: Gindex;
    optional: boolean;
};
/** Expected API of this View's type. This interface allows to break a recursive dependency between types and views */
export type StableContainerTypeGeneric<Fields extends Record<string, Type<unknown>>> = CompositeType<ValueOfFields<Fields>, ContainerTreeViewType<Fields>, unknown> & {
    readonly fields: Fields;
    readonly fieldsEntries: FieldEntry<NonOptionalFields<Fields>>[];
    tree_getActiveFields: (node: Node) => BitArray;
    tree_setActiveFields: (node: Node, activeFields: BitArray) => Node;
    tree_getActiveField: (node: Node, fieldIndex: number) => boolean;
    tree_setActiveField: (node: Node, fieldIndex: number, value: boolean) => Node;
};
export type ValueOfFields<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: ValueOf<Fields[K]>;
};
export type ViewType<T extends Type<unknown>> = T extends CompositeType<unknown, infer TV, unknown> ? TV : T extends BasicType<infer V> ? V : never;
export type OptionalViewType<T extends Type<unknown>> = T extends CompositeType<unknown, infer TV, unknown> ? // If composite, return view. MAY propagate changes updwards if not nullish
TV | null | undefined : T extends BasicType<infer V> ? V | null | undefined : never;
export type FieldsView<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends OptionalType<infer U> ? OptionalViewType<U> : ViewType<Fields[K]>;
};
export type ContainerTreeViewType<Fields extends Record<string, Type<unknown>>> = FieldsView<Fields> & TreeView<StableContainerTypeGeneric<Fields>>;
export type ContainerTreeViewTypeConstructor<Fields extends Record<string, Type<unknown>>> = {
    new (type: StableContainerTypeGeneric<Fields>, tree: Tree): ContainerTreeViewType<Fields>;
};
export declare function getContainerTreeViewClass<Fields extends Record<string, Type<unknown>>>(type: StableContainerTypeGeneric<Fields>): ContainerTreeViewTypeConstructor<Fields>;
type BytesRange = {
    start: number;
    end: number;
};
/**
 * Precompute fixed and variable offsets position for faster deserialization.
 * @throws when activeFields does not align with non-optional field types
 * @returns Does a single pass over all fields and returns:
 * - isFixedLen: If field index [i] is fixed length
 * - fieldRangesFixedLen: For fields with fixed length, their range of bytes
 * - variableOffsetsPosition: Position of the 4 bytes offset for variable size fields
 * - fixedEnd: End of the fixed size range
 * -
 */
export declare function computeSerdesData<Fields extends Record<string, Type<unknown>>>(activeFields: BitArray, fields: FieldEntry<Fields>[]): {
    isFixedLen: boolean[];
    fieldRangesFixedLen: BytesRange[];
    variableOffsetsPosition: number[];
    fixedEnd: number;
};
export {};
