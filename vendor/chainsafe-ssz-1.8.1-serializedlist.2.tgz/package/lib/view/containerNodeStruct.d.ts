import { Type } from "../type/abstract.ts";
import { ContainerTreeViewTypeConstructor, ContainerTypeGeneric } from "./container.ts";
export declare function getContainerTreeViewClass<Fields extends Record<string, Type<unknown>>>(type: ContainerTypeGeneric<Fields>): ContainerTreeViewTypeConstructor<Fields>;
