import { Node, Tree } from "@chainsafe/persistent-merkle-tree";
import { ValueOf } from "../type/abstract.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "../type/composite.ts";
import { TreeView } from "./abstract.ts";
import { ArrayType } from "./arrayBasic.ts";
/** Expected API of this View's type. This interface allows to break a recursive dependency between types and views */
export type ArrayCompositeType<ElementType extends CompositeType<unknown, CompositeView<ElementType>, CompositeViewDU<ElementType>>> = CompositeType<ValueOf<ElementType>[], unknown, unknown> & ArrayType & {
    readonly elementType: ElementType;
    readonly chunkDepth: number;
};
export declare class ArrayCompositeTreeView<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends TreeView<ArrayCompositeType<ElementType>> {
    readonly type: ArrayCompositeType<ElementType>;
    protected tree: Tree;
    constructor(type: ArrayCompositeType<ElementType>, tree: Tree);
    /**
     * Number of elements in the array. Equal to the Uint32 value of the Tree's length node
     */
    get length(): number;
    /**
     * Returns the View's Tree rootNode
     */
    get node(): Node;
    /**
     * Get element at `index`. Returns a view of the Composite element type
     */
    get(index: number): CompositeView<ElementType>;
    /**
     * Get element at `index`. Returns a view of the Composite element type.
     * DOES NOT PROPAGATE CHANGES: use only for reads and to skip parent references.
     */
    getReadonly(index: number): CompositeView<ElementType>;
    /**
     * Set Composite element type `view` at `index`
     */
    set(index: number, view: CompositeView<ElementType>): void;
    /**
     * Returns an array of views of all elements in the array, from index zero to `this.length - 1`.
     * The returned views don't have a parent hook to this View's Tree, so changes in the returned views won't be
     * propagated upwards. To get linked element Views use `this.get()`
     * @param views optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAllReadonly(views?: CompositeView<ElementType>[]): CompositeView<ElementType>[];
    /**
     * Returns an array of values of all elements in the array, from index zero to `this.length - 1`.
     * The returned values are not Views so any changes won't be propagated upwards.
     * To get linked element Views use `this.get()`
     * @param values optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAllReadonlyValues(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
}
