import { Gindex, Tree } from "@chainsafe/persistent-merkle-tree";
import { Type, ValueOf } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { CompositeType } from "../type/composite.ts";
import { NonOptionalFields } from "../type/optional.ts";
import { BitArray } from "../value/bitArray.ts";
import { TreeView } from "./abstract.ts";
export type FieldEntry<Fields extends Record<string, Type<unknown>>> = {
    fieldName: keyof Fields;
    fieldType: Fields[keyof Fields];
    jsonKey: string;
    gindex: Gindex;
    chunkIndex: number;
    optional: boolean;
};
/** Expected API of this View's type. This interface allows to break a recursive dependency between types and views */
export type ContainerTypeGeneric<Fields extends Record<string, Type<unknown>>> = CompositeType<ValueOfFields<Fields>, ContainerTreeViewType<Fields>, unknown> & {
    readonly fields: Fields;
    readonly fieldsEntries: FieldEntry<NonOptionalFields<Fields>>[];
    readonly activeFields: BitArray;
};
export type ValueOfFields<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: ValueOf<Fields[K]>;
};
export type FieldsView<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends CompositeType<unknown, infer TV, unknown> ? TV : Fields[K] extends BasicType<infer V> ? V : never;
};
export type ContainerTreeViewType<Fields extends Record<string, Type<unknown>>> = FieldsView<Fields> & TreeView<ContainerTypeGeneric<Fields>>;
export type ContainerTreeViewTypeConstructor<Fields extends Record<string, Type<unknown>>> = {
    new (type: ContainerTypeGeneric<Fields>, tree: Tree): ContainerTreeViewType<Fields>;
};
export declare function getProfileTreeViewClass<Fields extends Record<string, Type<unknown>>>(type: ContainerTypeGeneric<Fields>): ContainerTreeViewTypeConstructor<Fields>;
type BytesRange = {
    start: number;
    end: number;
};
/**
 * Precompute fixed and variable offsets position for faster deserialization.
 * @returns Does a single pass over all fields and returns:
 * - isFixedLen: If field index [i] is fixed length
 * - fieldRangesFixedLen: For fields with fixed length, their range of bytes
 * - variableOffsetsPosition: Position of the 4 bytes offset for variable size fields
 * - fixedEnd: End of the fixed size range
 * - offsets are relative to the start of serialized active fields, after the Bitvector[N] of optional fields
 */
export declare function computeSerdesData<Fields extends Record<string, Type<unknown>>>(optionalFields: BitArray, fields: FieldEntry<Fields>[]): {
    isFixedLen: boolean[];
    fieldRangesFixedLen: BytesRange[];
    variableOffsetsPosition: number[];
    fixedEnd: number;
};
export {};
