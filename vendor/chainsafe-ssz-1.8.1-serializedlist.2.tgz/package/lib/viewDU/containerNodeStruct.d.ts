import { HashComputationLevel, Node } from "@chainsafe/persistent-merkle-tree";
import { BranchNodeStruct } from "../branchNodeStruct.ts";
import { Type } from "../type/abstract.ts";
import { ContainerTypeGeneric, ValueOfFields } from "../view/container.ts";
import { TreeViewDU } from "./abstract.ts";
import { ContainerTreeViewDUTypeConstructor } from "./container.ts";
export declare class ContainerNodeStructTreeViewDU<Fields extends Record<string, Type<unknown>>> extends TreeViewDU<ContainerTypeGeneric<Fields>> {
    readonly type: ContainerTypeGeneric<Fields>;
    protected valueChanged: ValueOfFields<Fields> | null;
    protected _rootNode: BranchNodeStruct<ValueOfFields<Fields>>;
    constructor(type: ContainerTypeGeneric<Fields>, node: Node);
    get node(): Node;
    get cache(): void;
    get value(): ValueOfFields<Fields>;
    /**
     * There are 2 cases:
     * - normal commit() or hashTreeRoot(): hcByLevel is null, no need to compute root
     * - batchHashTreeRoot(): hcByLevel is not null, need to compute root because this does not support HashComputation
     */
    commit(_?: number, hcByLevel?: HashComputationLevel[] | null): void;
    protected clearCache(): void;
}
export declare function getContainerTreeViewDUClass<Fields extends Record<string, Type<unknown>>>(type: ContainerTypeGeneric<Fields>): ContainerTreeViewDUTypeConstructor<Fields>;
