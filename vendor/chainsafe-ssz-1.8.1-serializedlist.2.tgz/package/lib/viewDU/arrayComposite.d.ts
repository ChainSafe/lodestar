import { HashComputationLevel, Node } from "@chainsafe/persistent-merkle-tree";
import { ValueOf } from "../type/abstract.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "../type/composite.ts";
import { ArrayCompositeType } from "../view/arrayComposite.ts";
import { TreeViewDU } from "./abstract.ts";
export type ArrayCompositeTreeViewDUCache = {
    nodes: Node[];
    caches: unknown[];
    length: number;
    nodesPopulated: boolean;
};
export declare class ArrayCompositeTreeViewDU<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends TreeViewDU<ArrayCompositeType<ElementType>> {
    readonly type: ArrayCompositeType<ElementType>;
    protected _rootNode: Node;
    protected nodes: Node[];
    protected caches: unknown[];
    protected readonly viewsChanged: Map<number, CompositeViewDU<ElementType>>;
    protected _length: number;
    protected dirtyLength: boolean;
    private nodesPopulated;
    constructor(type: ArrayCompositeType<ElementType>, _rootNode: Node, cache?: ArrayCompositeTreeViewDUCache);
    /**
     * Number of elements in the array. Equal to un-commited length of the array
     */
    get length(): number;
    get node(): Node;
    get cache(): ArrayCompositeTreeViewDUCache;
    /**
     * Get element at `index`. Returns a view of the Composite element type.
     *
     * NOTE: Assumes that any view created here will change and will call .commit() on it.
     * .get() should be used only for cases when something may mutate. To get all items without
     * triggering a .commit() in all them use .getAllReadOnly().
     */
    get(index: number): CompositeViewDU<ElementType>;
    /**
     * Get element at `index`. Returns a view of the Composite element type.
     * DOES NOT PROPAGATE CHANGES: use only for reads and to skip parent references.
     */
    getReadonly(index: number): CompositeViewDU<ElementType>;
    /**
     * Set Composite element type `view` at `index`
     */
    set(index: number, view: CompositeViewDU<ElementType>): void;
    /**
     * Returns all elements at every index, if an index is modified it will return the modified view.
     * No need to commit() before calling this function.
     * @param views optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAllReadonly(views?: CompositeViewDU<ElementType>[]): CompositeViewDU<ElementType>[];
    /**
     * Apply `fn` to each ViewDU in the array.
     * Similar to getAllReadOnly(), no need to commit() before calling this function.
     * if an item is modified it will return the modified view.
     */
    forEach(fn: (viewDU: CompositeViewDU<ElementType>, index: number) => void): void;
    /**
     * WARNING: Returns all commited changes, if there are any pending changes commit them beforehand
     * @param values optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAllReadonlyValues(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
    /**
     * Apply `fn` to each value in the array
     */
    forEachValue(fn: (value: ValueOf<ElementType>, index: number) => void): void;
    /**
     * Get by range of indexes. Returns an array of views of the Composite element type.
     * This is similar to getAllReadonly() where we dont have to commit() before calling this function.
     */
    getReadonlyByRange(startIndex: number, count: number): CompositeViewDU<ElementType>[];
    /**
     * When we need to compute HashComputations (hcByLevel != null):
     *   - if old _rootNode is hashed, then only need to put pending changes to hcByLevel
     *   - if old _rootNode is not hashed, need to traverse and put to hcByLevel
     */
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    protected clearCache(): void;
    protected populateAllNodes(): void;
    /**
     * Similar to `populateAllNodes` but this does not require a commit() before reading all nodes.
     * If there are pendingChanges, they will NOT be included in the `nodes` array.
     */
    protected populateAllOldNodes(): void;
}
