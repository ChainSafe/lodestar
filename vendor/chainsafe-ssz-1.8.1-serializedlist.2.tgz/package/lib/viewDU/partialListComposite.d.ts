import { Node } from "@chainsafe/persistent-merkle-tree";
import { ValueOf } from "../type/abstract.ts";
import { CompositeType, CompositeView, CompositeViewDU } from "../type/composite.ts";
import { PartialListCompositeType } from "../type/partialListComposite.ts";
import { Snapshot } from "../util/types.ts";
import { ArrayCompositeTreeViewDUCache } from "./arrayComposite.ts";
import { ListCompositeTreeViewDU } from "./listComposite.ts";
/**
 * Similar to ListCompositeTreeViewDU but this is created from a snapshot so some methods are not supported
 * for some specific index ranges.
 * Note that the backed tree is not a full tree, but a partial tree created from a snapshot.
 */
export declare class PartialListCompositeTreeViewDU<ElementType extends CompositeType<ValueOf<ElementType>, CompositeView<ElementType>, CompositeViewDU<ElementType>>> extends ListCompositeTreeViewDU<ElementType> {
    readonly type: PartialListCompositeType<ElementType>;
    protected _rootNode: Node;
    private snapshot;
    constructor(type: PartialListCompositeType<ElementType>, _rootNode: Node, snapshot: Snapshot, cache?: ArrayCompositeTreeViewDUCache);
    /**
     * Create snapshot from the first `count` elements of the list.
     */
    toSnapshot(count: number): Snapshot;
    /** Methods in ArrayCompositeTreeViewDU */
    get(index: number): CompositeViewDU<ElementType>;
    getReadonly(index: number): CompositeViewDU<ElementType>;
    set(index: number, view: CompositeViewDU<ElementType>): void;
    getAllReadonly(): CompositeViewDU<ElementType>[];
    getAllReadonlyValues(): ValueOf<ElementType>[];
    /** Methods in ListCompositeTreeViewDU */
    /**
     * Similar to ListCompositeTreeViewDU.sliceTo() but:
     * - throw error if index < snapshot.count - 1
     * - special handle for index === snapshot.count - 1, we restore from snapshot
     */
    sliceTo(index: number): this;
    /**
     * Similar to ListCompositeTreeViewDU.sliceFrom() but here we cannot call `populateAllNodes()` to get all nodes
     * Use getNodesAtDepth() instead
     */
    sliceFrom(index: number): this;
    serializeToBytes(): number;
    /** Methods in TreeViewDU */
    /**
     * Does not support serialize and deserialize, it works through snapshot.
     */
    serialize(): Uint8Array;
    /**
     * Clone using rootNodeToViewDU() instead of getViewDU().
     */
    clone(dontTransferCache?: boolean): this;
    /**
     * Mainly used for testing, to ensure the snapshot is correct.
     * Set undefined values for items 0 to snapshot.count - 1
     */
    toValue(): ValueOf<ElementType>[];
    /**
     * Throw error because we only have partial tree in this case.
     */
    protected populateAllNodes(): void;
    /**
     * Since this.type.getViewDU() is not supported for this type, create a new PartialListCompositeTreeViewDU instead.
     */
    protected rootNodeToViewDU(rootNode: Node, cache?: ArrayCompositeTreeViewDUCache): this;
}
