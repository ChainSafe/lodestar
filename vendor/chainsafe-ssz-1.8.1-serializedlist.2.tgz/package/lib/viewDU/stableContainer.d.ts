import { Node } from "@chainsafe/persistent-merkle-tree";
import { Type } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { CompositeType } from "../type/composite.ts";
import { OptionalType } from "../type/optional.ts";
import { StableContainerTypeGeneric } from "../view/stableContainer.ts";
import { TreeViewDU } from "./abstract.ts";
export type ViewDUValue<T extends Type<unknown>> = T extends CompositeType<unknown, unknown, infer TVDU> ? TVDU : T extends BasicType<infer V> ? V : never;
export type OptionalViewDUValue<T extends Type<unknown>> = T extends CompositeType<unknown, unknown, infer TVDU> ? // If composite, return view. MAY propagate changes updwards
TVDU | null | undefined : T extends BasicType<infer V> ? V | null | undefined : never;
export type FieldsViewDU<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends OptionalType<infer U> ? OptionalViewDUValue<U> : ViewDUValue<Fields[K]>;
};
export type ContainerTreeViewDUType<Fields extends Record<string, Type<unknown>>> = FieldsViewDU<Fields> & TreeViewDU<StableContainerTypeGeneric<Fields>>;
export type ContainerTreeViewDUTypeConstructor<Fields extends Record<string, Type<unknown>>> = {
    new (type: StableContainerTypeGeneric<Fields>, node: Node, cache?: unknown): ContainerTreeViewDUType<Fields>;
};
export declare function getContainerTreeViewDUClass<Fields extends Record<string, Type<unknown>>>(type: StableContainerTypeGeneric<Fields>): ContainerTreeViewDUTypeConstructor<Fields>;
