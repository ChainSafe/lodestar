import { Node } from "@chainsafe/persistent-merkle-tree";
import { ByteViews, ValueOf } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { ListBasicType } from "../view/listBasic.ts";
import { ArrayBasicTreeViewDU, ArrayBasicTreeViewDUCache } from "./arrayBasic.ts";
export declare class ListBasicTreeViewDU<ElementType extends BasicType<unknown>> extends ArrayBasicTreeViewDU<ElementType> {
    readonly type: ListBasicType<ElementType>;
    protected _rootNode: Node;
    constructor(type: ListBasicType<ElementType>, _rootNode: Node, cache?: ArrayBasicTreeViewDUCache);
    /**
     * Adds one value element at the end of the array and adds 1 to the un-commited ViewDU length
     */
    push(value: ValueOf<ElementType>): void;
    /**
     * Returns a new ListBasicTreeViewDU instance with the values from 0 to `index`.
     * To achieve it, rebinds the underlying tree zero-ing all nodes right of `chunkIindex`.
     * Also set all value right of `index` in the same chunk to 0.
     */
    sliceTo(index: number): this;
    /**
     * Same method to `type/listBasic.ts` leveraging cached nodes.
     */
    serializeToBytes(output: ByteViews, offset: number): number;
}
