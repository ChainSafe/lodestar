import { HashComputationLevel, Node } from "@chainsafe/persistent-merkle-tree";
import { Type } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { CompositeType } from "../type/composite.ts";
import { BasicContainerTypeGeneric, ContainerTypeGeneric } from "../view/container.ts";
import { TreeViewDU } from "./abstract.ts";
export type FieldsViewDU<Fields extends Record<string, Type<unknown>>> = {
    [K in keyof Fields]: Fields[K] extends CompositeType<unknown, unknown, infer TVDU> ? TVDU : Fields[K] extends BasicType<infer V> ? V : never;
};
export type ContainerTreeViewDUType<Fields extends Record<string, Type<unknown>>> = FieldsViewDU<Fields> & TreeViewDU<ContainerTypeGeneric<Fields>>;
export type ContainerTreeViewDUTypeConstructor<Fields extends Record<string, Type<unknown>>> = {
    new (type: ContainerTypeGeneric<Fields>, node: Node, cache?: unknown): ContainerTreeViewDUType<Fields>;
};
export type ChangedNode = {
    index: number;
    node: Node;
};
type ContainerTreeViewDUCache = {
    nodes: Node[];
    caches: unknown[];
    nodesPopulated: boolean;
};
export declare class BasicContainerTreeViewDU<Fields extends Record<string, Type<unknown>>> extends TreeViewDU<BasicContainerTypeGeneric<Fields>> {
    readonly type: BasicContainerTypeGeneric<Fields>;
    protected _rootNode: Node;
    protected nodes: Node[];
    protected caches: unknown[];
    protected readonly nodesChanged: Set<number>;
    protected readonly viewsChanged: Map<number, unknown>;
    private nodesPopulated;
    constructor(type: BasicContainerTypeGeneric<Fields>, _rootNode: Node, cache?: ContainerTreeViewDUCache);
    get node(): Node;
    get cache(): ContainerTreeViewDUCache;
    /**
     * When we need to compute HashComputations (hcByLevel != null):
     *   - if old _rootNode is hashed, then only need to put pending changes to hcByLevel
     *   - if old _rootNode is not hashed, need to traverse and put to hcByLevel
     */
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    protected parseNodesChanged(nodes: ChangedNode[]): {
        indexes: number[];
        nodes: Node[];
    };
    protected clearCache(): void;
}
export declare function getContainerTreeViewDUClass<Fields extends Record<string, Type<unknown>>>(type: ContainerTypeGeneric<Fields>): ContainerTreeViewDUTypeConstructor<Fields>;
export {};
