import { HashComputationLevel, Node } from "@chainsafe/persistent-merkle-tree";
import { CompositeType } from "../type/composite.ts";
import { BitArray } from "../value/bitArray.ts";
import { TreeViewDU } from "./abstract.ts";
/**
 * Thin wrapper around BitArray to upstream changes after `this.commit()`
 */
export declare class BitArrayTreeViewDU extends TreeViewDU<CompositeType<BitArray, unknown, unknown>> implements BitArray {
    readonly type: CompositeType<BitArray, unknown, unknown>;
    protected _rootNode: Node;
    /** Cached BitArray instance computed only on demand */
    private _bitArray;
    constructor(type: CompositeType<BitArray, unknown, unknown>, _rootNode: Node);
    get node(): Node;
    get cache(): unknown;
    /** @see BitArray.uint8Array */
    get uint8Array(): Uint8Array;
    /** @see BitArray.bitLen */
    get bitLen(): number;
    /** Lazily computed bitArray instance */
    private get bitArray();
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    /** @see BitArray.get */
    get(bitIndex: number): boolean;
    /** @see BitArray.set */
    set(bitIndex: number, bit: boolean): void;
    /** @see BitArray.mergeOrWith */
    mergeOrWith(bitArray2: BitArray): void;
    /** @see BitArray.intersectValues */
    intersectValues<T>(values: ArrayLike<T>): T[];
    /** @see BitArray.getTrueBitIndexes */
    getTrueBitIndexes(): number[];
    /** @see BitArray.getSingleTrueBit */
    getSingleTrueBit(): number | null;
    /** @see BitArray.toBoolArray */
    toBoolArray(): boolean[];
    protected clearCache(): void;
}
