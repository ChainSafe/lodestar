import { HashComputationLevel, LeafNode, Node } from "@chainsafe/persistent-merkle-tree";
import { ValueOf } from "../type/abstract.ts";
import { BasicType } from "../type/basic.ts";
import { ArrayBasicType } from "../view/arrayBasic.ts";
import { TreeViewDU } from "./abstract.ts";
export type ArrayBasicTreeViewDUCache = {
    nodes: LeafNode[];
    length: number;
    nodesPopulated: boolean;
};
export declare class ArrayBasicTreeViewDU<ElementType extends BasicType<unknown>> extends TreeViewDU<ArrayBasicType<ElementType>> {
    readonly type: ArrayBasicType<ElementType>;
    protected _rootNode: Node;
    protected nodes: LeafNode[];
    protected readonly nodesChanged: Set<number>;
    protected _length: number;
    protected dirtyLength: boolean;
    private nodesPopulated;
    constructor(type: ArrayBasicType<ElementType>, _rootNode: Node, cache?: ArrayBasicTreeViewDUCache);
    /**
     * Number of elements in the array. Equal to un-commited length of the array
     */
    get length(): number;
    get node(): Node;
    get cache(): ArrayBasicTreeViewDUCache;
    /**
     * Get element at `index`. Returns the Basic element type value directly
     */
    get(index: number): ValueOf<ElementType>;
    /**
     * Set Basic element type `value` at `index`
     */
    set(index: number, value: ValueOf<ElementType>): void;
    /**
     * Get all values of this array as Basic element type values, from index zero to `this.length - 1`
     * @param values optional output parameter, if is provided it must be an array of the same length as this array
     */
    getAll(values?: ValueOf<ElementType>[]): ValueOf<ElementType>[];
    /**
     * When we need to compute HashComputations (hcByLevel != null):
     *   - if old _rootNode is hashed, then only need to put pending changes to hcByLevel
     *   - if old _rootNode is not hashed, need to traverse and put to hcByLevel
     */
    commit(hcOffset?: number, hcByLevel?: HashComputationLevel[] | null): void;
    protected clearCache(): void;
}
